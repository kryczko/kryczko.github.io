#!/bin/bash
cd ..
rm DATA_* P_* time.dat
