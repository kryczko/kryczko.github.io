# Submission script for main executable of network code, just designed to check runtimes simply

date > time.dat
./run.sh > log
date >> time.dat
