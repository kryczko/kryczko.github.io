rm -f *.json
rm -f *-generated
rm -f *.dat
rm -rf pass_logs fail_logs stagnant_logs observables
