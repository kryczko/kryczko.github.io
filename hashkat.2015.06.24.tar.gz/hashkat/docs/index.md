![hashkat logo](/img/new_logo.svg "#k@")

<span style="color:black; font-family:Georgia; font-size:2em;">Welcome to the official #k@ documentation</span>

<span style="color:black; font-family:Georgia; font-size:1.5em;">June 2015 - This site is currently under construction. Please return regularly over the course of the summer for further updates. </span>

![#k@ Visualization](/img/front_page.png =1x "#k@ Visualization")

[hashkat.org](http://hashkat.org)

