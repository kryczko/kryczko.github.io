[hashkat.org](http://hashkat.org)

<span style="color:black; font-family:Georgia; font-size:1.5em;">June 2015 - This site is currently under construction. Please return regularly over the course of the summer for further updates. </span>

#Troubleshooting

With such an interactive program such as #k@, it is expected that one will receive errors in running their simulations from time to time. Here we will discuss some of the error messages you may receive while
working with #k@, and how to find a solution to these errors.
